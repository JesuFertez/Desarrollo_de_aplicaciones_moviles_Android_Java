package com.example.base2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class BuscarProducto extends AppCompatActivity {

    private EditText codProdB, nomProdB, precioProdB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_producto);

        codProdB=findViewById(R.id.tvCodigoB);
        nomProdB=findViewById(R.id.tvNombreB);
        precioProdB=findViewById(R.id.tvPrecioB);
    }
    public void buscarProducto (View v){

        AdminDB admin= new AdminDB(this,"Productos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigo=codProdB.getText().toString();


        if (!codigo.isEmpty()){

            Cursor fila=base.rawQuery("select nombre,precio,codigo from producto where codigo="+codigo,null);
            if(fila.moveToFirst()){
                nomProdB.setText(fila.getString(0));
                precioProdB.setText(fila.getString(1));
            }else{
                Toast.makeText(this, "El producto no existe", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(this, "Debe ingresar un código o nombre del producto", Toast.LENGTH_LONG).show();
        }
    }
public void volver(View v){
    Intent volver= new Intent(this, MainActivity.class);
    startActivity(volver);
}
}
