package com.example.base2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EliminarProducto extends AppCompatActivity {
    private EditText codProdE,nomProdE,precioProdE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar_producto);
        codProdE=findViewById(R.id.tvCodigoE);
        nomProdE=findViewById(R.id.tvNombreE);
        precioProdE=findViewById(R.id.tvPrecioE);

    }
    public void eliminarProd (View v){
        AdminDB admin=new AdminDB(this,"Productos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();
        String codigo=codProdE.getText().toString();

        if(!codigo.isEmpty()){
            codProdE.setText("");
            nomProdE.setText("");
            precioProdE.setText("");

            int cantidad=base.delete("producto", "codigo="+codigo,null);
            base.close();
            if(cantidad==1){
            Toast.makeText(this, "El producto ha sido eliminado", Toast.LENGTH_LONG).show();
            }else{Toast.makeText(this,"Producto no existe",Toast.LENGTH_LONG).show();}
        }else{
            Toast.makeText(this,"Debe ingresar un código o nombre del producto ",Toast.LENGTH_LONG).show();
        }
    }
    public void volver(View v){
        Intent volver=new Intent(this, MainActivity.class);
        startActivity(volver);
    }
}