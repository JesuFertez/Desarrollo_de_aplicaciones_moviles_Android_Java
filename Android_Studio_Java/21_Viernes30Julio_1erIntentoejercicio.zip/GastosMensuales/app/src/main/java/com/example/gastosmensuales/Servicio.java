package com.example.gastosmensuales;

public class Servicio {
    private int codigo;
    private String servicio;


    public void  Servicio (){
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

}
