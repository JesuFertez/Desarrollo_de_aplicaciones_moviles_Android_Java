package com.example.gastosmensuales;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText montoG;
    private Spinner servicioS, mesS;
    private String[] serv={ "Selecione Servicio","Luz","Agua","Gas","Internet","Telefono","Feria","Super"};
    private String[] meses={"Seleccione un mes","Enero","Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        servicioS=findViewById(R.id.spServicio);
        ArrayAdapter <String> spinerSer=new ArrayAdapter(this, android.R.layout.simple_spinner_item,serv);
        servicioS.setAdapter(spinerSer);

        mesS=findViewById(R.id.spinnerMes);
        ArrayAdapter <String> spinerMes=new ArrayAdapter(this, android.R.layout.simple_spinner_item,meses);
        mesS.setAdapter(spinerMes);

        montoG=findViewById(R.id.edtcosto);
    }



    public void crearRegistro(View v){
        AdminDB admin=new AdminDB(this,"Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String servicio=servicioS.getSelectedItem().toString();
        String mes=mesS.getSelectedItem().toString();
        String monto=montoG.getText().toString();

        if(!servicio.isEmpty()&&!mes.isEmpty()&&!monto.isEmpty()){
            ContentValues crear=new ContentValues();

            crear.put("servicio",servicio);
            crear.put("mes",mes);
            crear.put("monto",monto);

            base.insert("GastosMensuales",null,crear);
            //base.close();

            ArrayAdapter <String> spinerSer=new ArrayAdapter(this, android.R.layout.simple_spinner_item);
            servicioS.setAdapter(spinerSer);

            ArrayAdapter  <String> spinerMes=new ArrayAdapter(this, android.R.layout.simple_spinner_item);
            mesS.setAdapter(spinerMes);

            montoG.setText("");

            Toast.makeText(this,"El registro a sido creado",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Debe rellenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

    public void irConsulta(View v){
        Intent irConsulta= new Intent(this,ConsultasBD.class);
        startActivity(irConsulta);
    }
}