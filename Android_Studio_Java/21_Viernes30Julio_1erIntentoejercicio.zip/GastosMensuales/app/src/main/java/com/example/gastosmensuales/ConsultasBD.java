package com.example.gastosmensuales;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.Date;
import java.util.ArrayList;

public class ConsultasBD extends AppCompatActivity {

     /*private Spinner servicio, fechaOP;
     private TextView codM,serM,fechaM,montoM;
     //private TextView gastoResultado;
    //private String [] meses={"Seleccione un mes","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};

     ArrayList <String> listaServicio;
     ArrayList <Servicio> servicioListado;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultas_bd);
       /* servicio=findViewById(R.id.spServicio);
        fechaOP=findViewById(R.id.spinner);

       // consultarlistaServicio();
        ArrayAdapter<String> adatador=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,listaServicio);
        ArrayAdapter<String> adapMeses=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,meses);

        //operacion.setAdapter(adaptadorop);
        servicio.setAdapter(adatador);
        fechaOP.setAdapter(adapMeses);
        montoM=findViewById(R.id.tv4);
*/
    }
/*
    //RELLENADO DE SERVICIO
    public void consultarlistaServicio(){
        AdminDB admin=new AdminDB(this, "Gastos",null,1);
        SQLiteDatabase base= admin.getWritableDatabase();

        Servicio p1=null;
        servicioListado=new ArrayList<Servicio>();
        Cursor fila=base.rawQuery("select * from GastosMensuales",null);
        while (fila.moveToNext()){
            p1=new Servicio();
            p1.setCodigo(fila.getInt(0));
            p1.setServicio(fila.getString(1));
            servicioListado.add(p1);
        }
        base.close();
        consultarServicio();
    }
    public void consultarServicio(){
        listaServicio=new ArrayList<String>();
        for (int i=0; i<servicioListado.size(); i++){
            listaServicio.add(servicioListado.get(i).getCodigo()+""+servicioListado.get(i).getServicio());
        }
    }
*/

   /* public void buscarGasto(View v){
        AdminDB admin =new AdminDB(this, "Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();
        String serv=servicio.getSelectedItem().toString();
        String fecha= fechaOP.getSelectedItem().toString();

        if(!serv.isEmpty()&&!fecha.isEmpty()){
            Cursor fila= base.rawQuery("select monto from GastosMensuales where servicio="+serv+"and fecha like %"+fecha,null);
            if (fila.moveToFirst()){
                montoM.setText(fila.getInt(0));
            }
        }

        //String op=operacion.getSelectedItem().toString();

        // if(operacion.equals("Gasto total")){
            //Cursor fila= base.rawQuery("select fecha,sum(monto) from GastosMensuales where fecha="+);
        //
        // }
        // (operacion.equals("Gasto máximo))
        //(operacion.equals("Gasto minimo))
    }*/

}