package com.example.a3eraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText t1, t2;
    private TextView t3;
    private RadioButton Suma, Resta, Mult, Div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1 = findViewById(R.id.tnum1);
        t2 = findViewById(R.id.tn2);
        t3 = findViewById(R.id.tvresul);

        Suma = findViewById(R.id.rBSuma);
        Resta = findViewById(R.id.rBResta);
        Mult = findViewById(R.id.rBMult);
        Div = findViewById(R.id.rBDiv);
    }

    public void op(View v) {
        int valor1 = Integer.parseInt(t1.getText().toString());
        int valor2 = Integer.parseInt(t2.getText().toString());

        if (Suma.isChecked()) {
            int sum = valor1 + valor2;
            t3.setText("El resultado de la suma es:" + sum);
        } else if (Resta.isChecked()) {
            int rest = valor1 - valor2;
            t3.setText("El resultado de la resta es:" + rest);
        } else if (Mult.isChecked()) {
            int mul = valor1 * valor2;
            t3.setText("El resultado de la multiplicación es:" + mul);
        } else if (Div.isChecked()) {
            if (valor2 <= 0) {
                t3.setText("No se puede dividir por 0");
            } else {
                int dv = valor1 / valor2;
                t3.setText("El resultado de la divición es:" + dv);
            }
        }
    }
}
