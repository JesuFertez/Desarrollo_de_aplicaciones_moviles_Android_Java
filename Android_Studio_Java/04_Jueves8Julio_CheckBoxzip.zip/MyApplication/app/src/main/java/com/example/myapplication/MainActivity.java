package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText tnum1, tnum2;
    private TextView tnum3;
    private CheckBox Suma, Resta, Mult, Div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tnum1= findViewById(R.id.txNum1);
        tnum2= findViewById(R.id.TxNum2);
        tnum3= findViewById(R.id.tvResult);
        Suma= findViewById(R.id.ckSuma);
        Resta= findViewById(R.id.ckResta);
        Mult= findViewById(R.id.ckMult);
        Div= findViewById(R.id.ckDiv);

    }

    public void op(View v){
        int valor1= Integer.parseInt(tnum1.getText().toString());
        int valor2= Integer.parseInt(tnum2.getText().toString());

        if (Suma.isChecked()) {
            int sum= valor1+valor2;
            tnum3.setText("El resultado es: "+sum);
        }else if (Resta.isChecked()){
            int res=valor1-valor2;
            tnum3.setText("El resultado es: "+res);
        }else if (Mult.isChecked()){
            int mul=valor1*valor2;
            tnum3.setText("El resultado es: "+ mul);
        }else if(Div.isChecked()){
            if (valor2<=0){
                tnum3.setText("No se puede dividir por 0");
            }else{
                int dv=valor1/valor2;
                tnum3.setText("El resultado es: "+dv);
            }
        }
    }
}