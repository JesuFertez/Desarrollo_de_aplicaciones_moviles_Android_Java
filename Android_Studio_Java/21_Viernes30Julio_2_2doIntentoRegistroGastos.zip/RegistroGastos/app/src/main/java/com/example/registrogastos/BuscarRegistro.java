package com.example.registrogastos;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class BuscarRegistro extends AppCompatActivity {
    private EditText codigoB, servicioB, añoB, costoB;
    private Spinner mesB;
    private String [] meses={"Seleccione un mes","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_registro);

        codigoB=findViewById(R.id.edtcodigoB);
        servicioB=findViewById(R.id.edtservicio);
        añoB=findViewById(R.id.editTextNumber);
        costoB=findViewById(R.id.edtcosto);
        mesB=findViewById(R.id.spinnerMesB);

        ArrayAdapter<String> adapMeses=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,meses);
        mesB.setAdapter(adapMeses);

    }

    public void buscarGasto (View v){

        /*AdminDB admin= new AdminDB(this,"Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String mes= mesB.getSelectedItem().toString();
        String servicio=servicioB.getText().toString();


        if (!mes.isEmpty()&& !servicio.isEmpty()){

            Cursor fila=base.rawQuery("select año,costo from GastosMensuales where mes="+mes, null);
            if(fila.moveToFirst()){
                servicioB.
                añoB.setText(fila.getString(0));
                costoB.setText(fila.getString(1));
            }else{
                Toast.makeText(this, "El producto no existe", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(this, "Debe ingresar un código o nombre del producto", Toast.LENGTH_LONG).show();
        }*/

        AdminDB admin= new AdminDB(this,"Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigo=codigoB.getText().toString();


        if (!codigo.isEmpty()){

            Cursor fila=base.rawQuery("select servicio,mes,año,costo from GastosMensuales where codigo="+codigo,null);
            if(fila.moveToFirst()){
                servicioB.setText(fila.getString(0));
                mesB.setText(fila.getString(1));
                añoB.setText(fila.getString(2));
                costoB.setText(fila.getString(3));
            }else{
                Toast.makeText(this, "El producto no existe", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(this, "Debe ingresar un código o nombre del producto", Toast.LENGTH_LONG).show();
        }
    }
}