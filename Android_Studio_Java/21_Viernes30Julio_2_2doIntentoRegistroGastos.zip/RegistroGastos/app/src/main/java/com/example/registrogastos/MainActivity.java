package com.example.registrogastos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void irCrearRegistro(View v){
        Intent ir=new Intent(this,CrearRegistro.class);
        startActivity(ir);

    }
    public void irBuscarRegistro(View v){
        Intent ir=new Intent(this,BuscarRegistro.class);
        startActivity(ir);

    }
    public void irCompararRegistro(View v) {
        Intent ir = new Intent(this, CompararGastos.class);
        startActivity(ir);
    }
}