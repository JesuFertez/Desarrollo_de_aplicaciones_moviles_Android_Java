package com.example.registrogastos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class CrearRegistro extends AppCompatActivity {
    private EditText codigoS, servicioN, añoS, costoS;
    private Spinner mesS;
    private String [] meses={"Seleccione un mes","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_registro);
        codigoS=findViewById(R.id.edtcodigoB);
        servicioN=findViewById(R.id.edtservicio);
        añoS=findViewById(R.id.editTextNumber);
        costoS=findViewById(R.id.edtcosto);
        mesS=findViewById(R.id.spMes);

        ArrayAdapter<String> adapMeses=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,meses);
        mesS.setAdapter(adapMeses);
    }
    public void crearRegistro(View v){
        AdminDB admin=new AdminDB (this,"Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigo=codigoS.getText().toString();
        String servicio=servicioN.getText().toString();
        String mes=mesS.getSelectedItem().toString();
        String año=añoS.getText().toString();
        String costo=costoS.getText().toString();

        if(!codigo.isEmpty()&&!servicio.isEmpty()&&!costo.isEmpty()&&!mes.isEmpty()&&!año.isEmpty()){
            ContentValues crear=new ContentValues();
            crear.put("codigo",codigo);
            crear.put("servicio",servicio);
            crear.put("mes",mes);
            crear.put("año",año);
            crear.put("costo",costo);

            base.insert("GastosMensuales",null,crear);
            base.close();

            codigoS.setText("");
            servicioN.setText("");
            mesS.setAdapter(null);
            añoS.setText("");
            costoS.setText("");

            Toast.makeText(this,"El registro a sido creado",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Debe rellenar todos los campos", Toast.LENGTH_SHORT).show();
        }
        }

    /*public void crearNuevoRegistrobasico(View v){
        AdminDB admin=new AdminDB (this,"Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigo=codigoS.getText().toString();
        String servicio=servicioN.getText().toString();
        String mes=mesS.getSelectedItem().toString();
        String año=añoS.getText().toString();
        String costo=costoS.getText().toString();

        if(!codigo.isEmpty()&&!servicio.isEmpty()&&!costo.isEmpty()&&!mes.isEmpty()&&!año.isEmpty()){
            ContentValues crear=new ContentValues();
            crear.put("codigo",codigo);
            crear.put("servicio",servicio);
            crear.put("mes",mes);
            crear.put("año",año);
            crear.put("costo",costo);

            base.insert("GastosMensuales",null,crear);
            base.close();

            codigoS.setText("");
            servicioN.setText("");
            mesS.setAdapter(null);
            añoS.setText("");
            costoS.setText("");

            Toast.makeText(this,"El registro a sido creado",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Debe rellenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }*/
}