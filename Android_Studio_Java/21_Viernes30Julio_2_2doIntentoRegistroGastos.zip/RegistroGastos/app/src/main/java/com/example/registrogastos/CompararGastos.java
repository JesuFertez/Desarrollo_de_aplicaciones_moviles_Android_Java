package com.example.registrogastos;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Toast;

public class CompararGastos extends AppCompatActivity {
    private EditText codigoC, servicioC, añoC, costoC;
    private AutoCompleteTextView mesC;

    private EditText codigoOG, servicioOG, añoOG, costoOG;
    private AutoCompleteTextView mesOG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparar_gastos);

        codigoC=findViewById(R.id.edtcodigoB);
        servicioC=findViewById(R.id.edtservicio);
        añoC=findViewById(R.id.editTextNumber);
        costoC=findViewById(R.id.edtcosto);
        mesC=findViewById(R.id.autoCompleteTextView);

        // Parametros a comparar

        codigoOG=findViewById(R.id.edtCódigoOG);
        servicioOG=findViewById(R.id.edtServicioOG);
        añoOG=findViewById(R.id.edtAñoOG);
        costoOG=findViewById(R.id.edtCostoOG);
        mesOG=findViewById(R.id.edtMesOG);

    }

    public void CompararPorMes(View v){
        AdminDB admin= new AdminDB(this,"Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String MesA=mesC.getText().toString();
        String SerA=servicioC.getText().toString();
        String MesB=mesOG.getText().toString();

        if(!MesA.isEmpty()&&!SerA.isEmpty()){
            Cursor fila=base.rawQuery("select año,costo from GastosMensuales where mes="+MesA+"(and servicio=)"+SerA,null);
            if(fila.moveToFirst()){
                servicioC.setText(fila.getString(0));
                mesC.setText(fila.getString(1));
                añoC.setText(fila.getString(2));
                costoC.setText(fila.getString(3));
            }else{
                Toast.makeText(this, "El registro no existe", Toast.LENGTH_LONG).show();
            }
        }
        }

    public void CompararGastoCodigo (View v){

        AdminDB admin= new AdminDB(this,"Gastos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigoA=codigoC.getText().toString();
        String codigoB=codigoOG.getText().toString();

        if (!codigoA.isEmpty()){

            Cursor fila=base.rawQuery("select servicio,mes,año,costo from GastosMensuales where codigo="+codigoA,null);
            if(fila.moveToFirst()){
                servicioC.setText(fila.getString(0));
                mesC.setText(fila.getString(1));
                añoC.setText(fila.getString(2));
                costoC.setText(fila.getString(3));
            }else{
                Toast.makeText(this, "El registro no existe", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(this, "Debe ingresar un código válido", Toast.LENGTH_LONG).show();
        }
        if (!codigoB.isEmpty()){

            Cursor fila=base.rawQuery("select servicio,mes,año,costo from GastosMensuales where codigo="+codigoB,null);
            if(fila.moveToFirst()){
                servicioOG.setText(fila.getString(0));
                mesOG.setText(fila.getString(1));
                añoOG.setText(fila.getString(2));
                costoOG.setText(fila.getString(3));
            }else{
                Toast.makeText(this, "El registro no existe", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(this, "Debe ingresar registro válido", Toast.LENGTH_LONG).show();
        }
    }
}