package com.example.baseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText codProd,NomProd,PrecioProd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        codProd= findViewById(R.id.codProd);
        NomProd= findViewById(R.id.NomProd);
        PrecioProd= findViewById(R.id.PrecioProd);
    }
    public void crearProducto(View v){

        AdminDB admin= new AdminDB(this,"Productos",null,1);
        SQLiteDatabase base= admin.getWritableDatabase();

        String codigo=codProd.getText().toString();
        String nombre=NomProd.getText().toString();
        String precio=PrecioProd.getText().toString();

        if(!codigo.isEmpty() && !nombre.isEmpty() && !precio.isEmpty()){

            ContentValues crear=new ContentValues();
            crear.put("codigo",codigo);
            crear.put("nombre",nombre);
            crear.put("precio",precio);

            base.insert("producto",null,crear);
            codProd.setText("");
            NomProd.setText("");
            PrecioProd.setText("");
            Toast.makeText(this,"Registro creado",Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(this,"Debe completar todos los campos", Toast.LENGTH_LONG).show();
        }
    }
    public void buscarProducto(View v){

        AdminDB admin=new AdminDB(this, "Productos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigo=codProd.getText().toString();

        if(!codigo.isEmpty()){
            Cursor fila=base.rawQuery("select nombre, precio from producto where codigo="+codigo, null);
            if(fila.moveToFirst()){
               NomProd.setText(fila.getString(0));
               PrecioProd.setText(fila.getString(1));

            }else{
                Toast.makeText(this, "El producto no existe", Toast.LENGTH_SHORT).show();
            }

        }else{
            Toast.makeText(this,"Debe ingresar un código de producto", Toast.LENGTH_LONG).show();
        }
    }

    public void modificarProducto(View v){
        AdminDB admin=new AdminDB(this, "Productos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigo=codProd.getText().toString();
        String nombre=NomProd.getText().toString();
        String precio=PrecioProd.getText().toString();

        if(!codigo.isEmpty() && !nombre.isEmpty() && !precio.isEmpty()){

            ContentValues modificar=new ContentValues();
            modificar.put("codigo",codigo);
            modificar.put("nombre",nombre);
            modificar.put("precio",precio);

            base.update("producto",modificar,"codigo="+codigo,null);
            base.close();
            codProd.setText("");
            NomProd.setText("");
            PrecioProd.setText("");
            Toast.makeText(this,"Registro modificado",Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(this,"Debe completar todos los campos", Toast.LENGTH_LONG).show();
        }
    }

    public void eliminarProducto(View v) {

        AdminDB admin=new AdminDB(this,"Productos",null,1);
        SQLiteDatabase base= admin.getWritableDatabase();

        String codigo=codProd.getText().toString();

        if(!codigo.isEmpty()){

            codProd.setText("");
            NomProd.setText("");
            PrecioProd.setText("");

            int cantidad = base.delete("producto","codigo="+codigo,null);
          if(cantidad==1){
              Toast.makeText(this,"El producto ha sido eliminado",Toast.LENGTH_LONG).show();
          }else {
              Toast.makeText(this,"El producto no existe", Toast.LENGTH_LONG).show();
          }
        }else{
            Toast.makeText(this,"Debe ingresar un código",Toast.LENGTH_LONG).show();
        }
    }
}                                                               