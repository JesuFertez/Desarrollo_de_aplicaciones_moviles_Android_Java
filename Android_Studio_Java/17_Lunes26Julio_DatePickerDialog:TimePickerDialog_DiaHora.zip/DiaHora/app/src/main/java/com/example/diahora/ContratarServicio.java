package com.example.diahora;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

public class ContratarServicio extends AppCompatActivity {
    private EditText edtHora, edtFecha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contratar_servicio);

        edtFecha=findViewById(R.id.edtFecha);
        edtHora=findViewById(R.id.edtHora);
    }
    public void mostrarCalendario (View v){
        DatePickerDialog d=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                edtFecha.setText(dayOfMonth+"/"+(month+1)+"/"+year);
            }
        },2021,0,1);
        d.show();
    }
    public void mostrarHorario(View v){
        TimePickerDialog d=new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                edtHora.setText(hourOfDay+":"+minute);
            }
        },12,30,true);
        d.show();
    }
    public void volver(View v){
        Intent volver=new Intent (this,MainActivity.class);
        startActivity(volver);
    }
}