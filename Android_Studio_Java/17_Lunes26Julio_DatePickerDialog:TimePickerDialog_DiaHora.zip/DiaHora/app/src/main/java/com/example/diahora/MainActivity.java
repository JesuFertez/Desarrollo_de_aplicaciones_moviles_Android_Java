package com.example.diahora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void contratarServicio(View v){
        Intent manda=new Intent(this,ContratarServicio.class);
        startActivity(manda);}


    public void demo(View v){
            Toast.makeText(this, "Esta función no está disponible en la versión Demo", Toast.LENGTH_SHORT).show();

        }
}