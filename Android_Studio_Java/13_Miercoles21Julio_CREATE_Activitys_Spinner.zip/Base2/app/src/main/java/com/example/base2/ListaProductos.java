package com.example.base2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class ListaProductos extends AppCompatActivity {

    private Spinner spproducto;
    ArrayList<String> listaProductos;
    ArrayList<Producto> productosLista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_productos);

        spproducto=findViewById(R.id.spinner);

        consultarListaProductos();
        ArrayAdapter<String> adaptador= new ArrayAdapter(this,android.R.layout.simple_spinner_item,listaProductos);
        spproducto.setAdapter(adaptador);
    }

    public void consultarListaProductos(){
        AdminDB admin=new AdminDB(this, "Productos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        Producto p1=null;
        productosLista=new ArrayList<Producto>();
        Cursor fila=base.rawQuery("select * from producto",null);
        while(fila.moveToNext()){
            p1=new Producto();
            p1.setCodigo(fila.getInt(0));
            p1.setNombre(fila.getString(1));
            p1.setPrecio(fila.getInt(2));
            productosLista.add(p1);
        }
        base.close();
        consultarProducto();
    }
    public void consultarProducto() {
        listaProductos = new ArrayList<String>();
        for (int i = 0; i < productosLista.size(); i++) {
            listaProductos.add(productosLista.get(i).getCodigo() + "  " + productosLista.get(i).getNombre() + "  " + productosLista.get(i).getPrecio());
        }
    }
    public void volver (View v){
        Intent volver=new Intent(this,MainActivity.class);
        startActivity (volver);
    }
}