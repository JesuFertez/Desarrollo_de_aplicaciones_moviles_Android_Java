package com.example.base2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class CrearProducto extends AppCompatActivity {

    private EditText codProd,nomProd,precioProd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_producto);

        codProd=findViewById(R.id.tvCodigo);
        nomProd=findViewById(R.id.tvNombre);
        precioProd=findViewById(R.id.tvPrecio);

    }
    public void crearProd (View v){
        AdminDB admin= new AdminDB(this, "Productos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();

        String codigo=codProd.getText().toString();
        String nombre=nomProd.getText().toString();
        String precio=precioProd.getText().toString();

        if(!codigo.isEmpty() && !nombre.isEmpty() && !precio.isEmpty()){
            ContentValues crear= new ContentValues();
            crear.put("codigo",codigo);
            crear.put("nombre",nombre);
            crear.put("precio",precio);

            base.insert("producto",null,crear);
            base.close();

            codProd.setText("");
            nomProd.setText("");
            precioProd.setText("");

            Toast.makeText(this, "El registro ha sido creado", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this, "Debe completar todos los campos", Toast.LENGTH_LONG).show();
        }
    }
    public void volver (View v){
        Intent volver=new Intent(this,MainActivity.class);
        startActivity (volver);
    }
}
