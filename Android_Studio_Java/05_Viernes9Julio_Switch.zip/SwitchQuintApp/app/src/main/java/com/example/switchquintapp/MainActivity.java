package com.example.switchquintapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText num1, num2;
    private TextView tv1;
    private Switch suma, resta, mult, div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1=findViewById(R.id.TxNum1);
        num2=findViewById(R.id.TxNum2);
        tv1=findViewById(R.id.tvResult);
        suma=findViewById(R.id.swSuma);
        resta=findViewById(R.id.swResta);
        mult=findViewById(R.id.swMult);
        div=findViewById(R.id.swDiv);

    }

    public void op(View v){
        int valor1=Integer.parseInt(num1.getText().toString());
        int valor2=Integer.parseInt(num2.getText().toString());

        if(suma.isChecked()){
            int sum=valor1+valor2;
            tv1.setText("El resultado es: "+sum);
        }else if(resta.isChecked()){
            int rest=valor1-valor2;
            tv1.setText("El resultado es: "+rest);
        }else if (mult.isChecked()){
            int multi=valor1*valor2;
            tv1.setText("El resultado es: "+multi);
        }else if(div.isChecked()){
            if(valor2<=0){
                tv1.setText("No se puede dividir por 0");
            }else{
                int dv=valor1/valor2;
                tv1.setText("El resultado es: "+dv);
            }
        }

    }
}