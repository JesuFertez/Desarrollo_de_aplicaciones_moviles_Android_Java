package com.example.controlspinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText num1, num2;
    private TextView tvResult;
    private Spinner Sp1;
    private String [] op={"Seleccione una opción","Sumar","Restar","Multiplicar","Dividir"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1=findViewById(R.id.edtnum1);
        num2=findViewById(R.id.edtnum2);
        tvResult=findViewById(R.id.tvResultado);
        Sp1=findViewById(R.id.spinner);
        ArrayAdapter<String> adaptador=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,op);
        Sp1.setAdapter(adaptador);
    }
    public void operar(View v){

        int valor1=Integer.parseInt(num1.getText().toString());
        int valor2=Integer.parseInt(num2.getText().toString());
        String operacion=Sp1.getSelectedItem().toString();

        if(operacion.equals("Sumar")){
            int sum=valor1+valor2;
            tvResult.setText("El resultado es: "+sum);
        }else if (operacion.equals("Restar")){
            int res=valor1-valor2;
            tvResult.setText("El resultado es: "+res);
        }else if (operacion.equals("Multiplicar")){
            int mult=valor1*valor2;
            tvResult.setText("El resultado es: "+mult);
        }else if(operacion.equals("Dividir")){
            if (valor2<=0){
                tvResult.setText("No se puede dividir por 0");
            }else{
                int div=valor1/valor2;
                tvResult.setText("El resultado es: "+div);
            }
        }
    }
}