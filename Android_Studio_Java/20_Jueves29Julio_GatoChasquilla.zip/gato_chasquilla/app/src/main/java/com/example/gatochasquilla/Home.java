package com.example.gatochasquilla;

import androidx.appcompat.app.AppCompatActivity;

import android.app.VoiceInteractor;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Switch;

public class Home extends AppCompatActivity {
    private CheckBox prof;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        prof=findViewById(R.id.chBoxProfesional);

    }


    public void passHome(View v){
        if (prof.isChecked()){
            passRegistroProfesional();
        } else {
            passRegistroUsuario();
        }

    }

    public void passRegistroProfesional(){
        Intent regProf=new Intent(this, MainProfesional.class);
        startActivity(regProf);
    }


    public void passRegistroUsuario(){
        Intent regUs=new Intent(this, RegistroUsuarios.class);
        startActivity(regUs);
    }

    public void iralOtro(View v){
        Intent passh=new Intent(this, MainActivity.class);
        startActivity(passh);
    }


}