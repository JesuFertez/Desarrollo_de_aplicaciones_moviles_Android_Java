package com.example.gatochasquilla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainProfesional extends AppCompatActivity {
    private EditText tipo,nombres,apePater,apeMater,direc,telefono,mail;
    private Spinner listacomunas,listaregion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_profesional);
        //tipo=findViewById(R.id.editTipo);
        nombres=findViewById(R.id.editNombres);
        apePater=findViewById(R.id.editApePater);
        apeMater=findViewById(R.id.editApeMater);
        direc=findViewById(R.id.editDirec);
        telefono=findViewById(R.id.editFono);
        mail=findViewById(R.id.editMail);
        listacomunas=findViewById(R.id.spcomuna);
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this,R.array.lista_comunas, android.R.layout.simple_spinner_item);
        listacomunas.setAdapter(adapter);
        listaregion=findViewById(R.id.spregion);
        ArrayAdapter<CharSequence>adapter1=ArrayAdapter.createFromResource(this,R.array.lista_regiones, android.R.layout.simple_spinner_item);
        listaregion.setAdapter(adapter1);
    }
    public void crearproducto(View v){

        Admindb admindb = new Admindb(this,"Productos",null,1);
        SQLiteDatabase base = admindb.getWritableDatabase();
        String Stipo=tipo.getText().toString();
        String Snombres=nombres.getText().toString();
        String SapePater =apePater.getText().toString();
        String SapeMater =apeMater.getText().toString();
        String Sdirec =direc.getText().toString();
        String Stelefono =telefono.getText().toString();
        String Smail =mail.getText().toString();

        if(!Stipo.isEmpty() && !Snombres.isEmpty() && !SapePater.isEmpty())
        {
            ContentValues crear = new ContentValues();
            crear.put("tipo",Stipo);
            crear.put("nombres",Snombres);
            crear.put("apepat",SapePater);
            crear.put("apemat",SapeMater);
            crear.put("direccion",Sdirec);
            crear.put("telefono",Stelefono);
            crear.put("mail",Smail);


            base.insert("Profesionals",null,crear);
            base.close();
            tipo.setText("");
            nombres.setText("");
            apePater.setText("");
            apeMater.setText("");
            direc.setText("");
            telefono.setText("");
            mail.setText("");
            Toast.makeText(this,"Registro creado",Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this,"Debe completar todos los campos",Toast.LENGTH_LONG).show();
        }
    }
    public void volver(View view){
        Intent volver=new Intent(this, Home.class);
        startActivity(volver);
    }
}