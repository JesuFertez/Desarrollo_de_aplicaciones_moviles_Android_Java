package com.example.base2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void crearPro (View v){
        Intent crearPro=new Intent(this, CrearProducto.class);
        startActivity(crearPro);}

    public void buscarpro(View v){
        Intent buscarpro=new Intent(this, BuscarProducto.class);
        startActivity(buscarpro);
    }

    public void modificarPro(View v){
        Intent modificarPro= new Intent(this,ModificarProducto.class );
        startActivity(modificarPro);
    }
    public void eliminarPro(View v){
        Intent eliminarPro=new Intent(this, EliminarProducto.class );
        startActivity(eliminarPro);
    }

}