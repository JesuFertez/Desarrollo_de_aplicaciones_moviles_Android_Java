package com.example.base2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ModificarProducto extends AppCompatActivity {
    private EditText codProdM, nomProdM, precioProdM;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_producto);
        codProdM=findViewById(R.id.tvCodigoM);
        nomProdM=findViewById(R.id.tvNombreM);
        precioProdM=findViewById(R.id.tvPrecioM);

    }

    public void modProd (View v){
        AdminDB admin= new AdminDB(this,"Producto",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();
        String codigo=codProdM.getText().toString();
        String nombre=nomProdM.getText().toString();
        String precio=precioProdM.getText().toString();

        if(!codigo.isEmpty() && !nombre.isEmpty() && !precio.isEmpty()){
            ContentValues modificar=new ContentValues();
            modificar.put("codigo",codigo);
            modificar.put("nombre",nombre);
            modificar.put("precio",precio);

            base.update("producto",modificar,"codigo="+codigo,null);
            codProdM.setText("");
            nomProdM.setText("");
            precioProdM.setText("");
            Toast.makeText(this, "El registro ha sido modificado", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(this,"Debe completar todos los campos",Toast.LENGTH_LONG).show();
        }
    }
    public void volver(View v){
        Intent volver=new Intent(this,MainActivity.class);
        startActivity(volver);
    }
}