package com.example.base2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EliminarProducto extends AppCompatActivity {
    private EditText codProdE,nomProdE,precioProdE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eliminar_producto);
        codProdE=findViewById(R.id.tvCodigoE);
        nomProdE=findViewById(R.id.tvNombreE);
        precioProdE=findViewById(R.id.tvPrecioE);

    }
    public void eliminarProd (View v){
        AdminDB admin=new AdminDB(this,"Productos",null,1);
        SQLiteDatabase base=admin.getWritableDatabase();
        String codigo=codProdE.getText().toString();
        String nombre=nomProdE.getText().toString();

        if(!codigo.isEmpty() || !nombre.isEmpty()){
            codProdE.setText("");
            nomProdE.setText("");
            precioProdE.setText("");

            base.delete("producto", "codigo="+codigo "or nombre="+nombre,null);
            Toast.makeText(this, "El producto ha sido eliminado", Toast.LENGTH_LONG).show();

        }
    }
}