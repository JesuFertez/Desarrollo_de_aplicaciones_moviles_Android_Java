package com.example.basehogar;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class CompararRegistros extends AppCompatActivity {

   //private String[] serv={ "Selecione Servicio","Luz","Agua","Gas","Internet","Telefono","Feria","Super"};
    private String[] meses={"Seleccione un mes","Enero","Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

    private ArrayList lista1 = new ArrayList();
    private ArrayList lista2 = new ArrayList();

    private Spinner sp1, sp2;
    private ListView listv1,listv2;

    ArrayAdapter adp1, adp2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comparar_registros);

        sp1=findViewById(R.id.spinner1);
        ArrayAdapter <String> listaSeleccion1= new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,meses);
        sp1.setAdapter(listaSeleccion1);

        sp2=findViewById(R.id.spinner2);
        ArrayAdapter <String> listaSeleccion2= new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,meses);
        sp2.setAdapter(listaSeleccion2);

        listv1=findViewById(R.id.listv1);
        listv2=findViewById(R.id.listv2);

    }
    public void compararRegistro(View v){
        AdminDB admin = new AdminDB(this, "Gastos", null, 1);
        SQLiteDatabase base = admin.getWritableDatabase();

        if (!lista1.isEmpty() || !lista2.isEmpty()) {
            lista1.clear();
            lista2.clear();
        }

        String mesSel1=sp1.getSelectedItem().toString();

        Cursor registro1 = base.rawQuery("select * from GastosMensuales where mes like '"+mesSel1+"'",null);

        if (registro1.moveToFirst()){
            do {
                lista1.add(registro1.getString(0)
                        +" - "+registro1.getString(1)
                        +" - "+registro1.getString(2));
            } while (registro1.moveToNext());
        } else {
            Toast.makeText(this, "No se encontraron registros", Toast.LENGTH_SHORT).show();
        }
        adp1 = new ArrayAdapter(this, android.R.layout.simple_list_item_1, lista1);
        listv1.setAdapter(adp1);

        String mesSel2=sp2.getSelectedItem().toString();
        Cursor registros2 = base.rawQuery("select * from GastosMensuales where mes like '"+mesSel2+"'",null);
        if (registros2.moveToFirst()){
            do {
                lista2.add(registros2.getString(0)+" - "+registros2.getString(1)
                        +" - "+registros2.getString(2));
            } while (registros2.moveToNext());
        } else {
            Toast.makeText(this, "No se encontraron registros", Toast.LENGTH_SHORT).show();
        }

        adp2 = new ArrayAdapter(this, android.R.layout.simple_list_item_1, lista2);
        listv2.setAdapter(adp2);
    }
}