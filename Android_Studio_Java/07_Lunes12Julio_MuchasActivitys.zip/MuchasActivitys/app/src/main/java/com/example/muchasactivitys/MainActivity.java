package com.example.muchasactivitys;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void check(View v){
        Intent check= new Intent(this,CheckBockspagina.class);
    startActivity(check); }

    public void swichpag(View v){
        Intent swichpag= new Intent(this,swichPagina.class);
        startActivity(swichpag);}

        public void Spinnerpag(View v){ Intent Spinnerpag= new Intent(this,SpinnerPag.class);
        startActivity(Spinnerpag);}
}