package com.example.muchasactivitys;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class swichPagina extends AppCompatActivity {
    private EditText n1, n2;
    private TextView n3;
    private Switch  Suma, Resta, Mult, Div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_swich_pagina);

        n1= findViewById(R.id.Num1SW);
        n2= findViewById(R.id.Num2SW);
        n3= findViewById(R.id.tvResultadoSW);
        Suma= findViewById(R.id.SumarSW);
        Resta= findViewById(R.id.RestarSW);
        Mult= findViewById(R.id.MultiplicarSW);
        Div= findViewById(R.id.DividirSW);
    }
    public void op(View v) {
        int valor1 = Integer.parseInt(n1.getText().toString());
        int valor2 = Integer.parseInt(n2.getText().toString());

        if (Suma.isChecked()) {
            int sum = valor1 + valor2;
            n3.setText("El resultado es: " + sum);
        } else if (Resta.isChecked()) {
            int res = valor1 - valor2;
            n3.setText("El resultado es: " + res);
        } else if (Mult.isChecked()) {
            int mul = valor1 * valor2;
            n3.setText("El resultado es: " + mul);
        } else if (Div.isChecked()) {
            if (valor2 <= 0) {
                n3.setText("No se puede dividir por 0");
            } else {
                int dv = valor1 / valor2;
                n3.setText("El resultado es: " + dv);
            }
        }
    }
    public void volver(View v){
        Intent volver=new Intent(this, MainActivity.class);
        startActivity(volver); }
}