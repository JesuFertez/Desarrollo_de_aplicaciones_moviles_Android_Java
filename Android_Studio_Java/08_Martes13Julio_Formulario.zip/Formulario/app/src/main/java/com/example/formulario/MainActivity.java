package com.example.formulario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText nom,apell,mail,tele;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nom= findViewById(R.id.edtNombre);
        apell= findViewById(R.id.edtApellido);
        mail= findViewById(R.id.edtMail);
        tele= findViewById(R.id.edtPhone);

    }
    public void registro(View v){
        Intent registro= new Intent(this,Registrado.class);
        registro.putExtra("nombre",nom.getText().toString());
        registro.putExtra("apellido",apell.getText().toString());
        registro.putExtra("email",mail.getText().toString());
        registro.putExtra("telefono",tele.getText().toString());
        startActivity(registro);
    }
}