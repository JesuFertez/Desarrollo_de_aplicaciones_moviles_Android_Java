package com.example.formulario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Registrado extends AppCompatActivity {

    TextView nombre,apellido,maile,telef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrado);

        nombre=findViewById(R.id.textView2);
        apellido=findViewById(R.id.textView3);
        maile=findViewById(R.id.textView4);
        telef=findViewById(R.id.textView5);

        String nombre1=getIntent().getStringExtra("nombre");
        nombre.setText(""+nombre1);

        String apellido1=getIntent().getStringExtra("apellido");
        apellido.setText(""+apellido1);
        String maile1= getIntent().getStringExtra("email");
        maile.setText(""+maile1);
        String telefon=getIntent().getStringExtra("telefono");
        telef.setText(""+telefon);
    }

}